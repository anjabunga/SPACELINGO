public class DataContainer {
    private String wordy;
    private String digity;

    public String getWordy() {
        return wordy;
    }

    public void setWordy(String wordy) {
        this.wordy = wordy;
    }

    public String getDigity() {
        return digity;
    }

    public void setDigity(String digity) {
        this.digity = digity;
    }
}
