import java.util.Random;
import java.util.Scanner;

public class UAS {
    public static void main(String[] args) {
        System.out.println("Selamat datang di Aplikasi SpaceLingo!");
        System.out.println("Masukkan kalimat yang ingin Anda terjemahkan:");
        Scanner scanner = new Scanner(System.in);
        String inputSentence = scanner.nextLine();
        if (inputSentence != null) {
            try {
                String translatedSentence = translateToAlienLanguage(inputSentence);
                System.out.println("Kalimat terjemahan: " + translatedSentence);
                configureTranslator(inputSentence);
            } catch (Exception e) {
                System.out.println("Terjadi kesalahan saat menerjemahkan: " + e.getMessage());
            }
        } else {
            System.out.println("Masukan tidak valid.");
        }
    }

    private static String translateToAlienLanguage(String sentence) {
        StringBuilder alienSentence = new StringBuilder();
        Random random = new Random();

        for (char c : sentence.toCharArray()) {
            if ("aeiou".contains(Character.toLowerCase(c) + "")) {
                char randomChar = (char) ('A' + random.nextInt(26));
                alienSentence.append(randomChar);
            } else {
                alienSentence.append(c);
            }
        }
        return alienSentence.toString();
    }

    static class AlienTranslator {
        private String language;

        public AlienTranslator(String language) {
            this.language = language;
        }

        public void displayLanguage() {
            System.out.println("Bahasa yang digunakan: " + language);
        }
    }

    static class FakeAlienTranslator extends AlienTranslator {
        private String fakeAlphabet;

        public FakeAlienTranslator(String language, String fakeAlphabet) {
            super(language);
            this.fakeAlphabet = fakeAlphabet;
        }

        @Override
        public void displayLanguage() {
            super.displayLanguage();
            System.out.println("Alfabet palsu: " + fakeAlphabet);
        }
    }

    private static void configureTranslator(String originalText) {
        System.out.println("Apakah Anda ingin menambahkan kode rahasia? (ya/tidak)");
        Scanner scanner = new Scanner(System.in);
        String input = scanner.nextLine();
        if (input != null && input.toLowerCase().equals("ya")) {
            System.out.println("Masukkan 3 digit angka (1-9) untuk kode rahasia:");
            String inputCode = scanner.nextLine();
            if (inputCode != null && inputCode.length() == 3 && inputCode.chars().allMatch(Character::isDigit)) {
                try {
                    String secretCode = translateSecretCode(inputCode);
                    System.out.println("Kode rahasia Anda adalah: " + secretCode);
                    System.out.println("Jumlah huruf vokal dalam kalimat: " + countVowelsInSentence(secretCode));
                } catch (Exception e) {
                    System.out.println("Terjadi kesalahan saat mengonversi kode rahasia: " + e.getMessage());
                }
            } else {
                System.out.println("Input tidak valid. Pastikan Anda memasukkan 3 digit angka (1-10).");
            }
        } else {
            AlienTranslator translator = new AlienTranslator("Bahasa Alien");
            translator.displayLanguage();
        }
    }

    private static int countVowelsInSentence(String sentence) {
        int count = 0;
        for (char c : sentence.toCharArray()) {
            if ("aeiou".contains(Character.toLowerCase(c) + "")) {
                count++;
            }
        }
        return count;
    }

    private static String translateSecretCode(String inputCode) {
        StringBuilder secretCode = new StringBuilder();
        for (char c : inputCode.toCharArray()) {
            Integer digit = Character.getNumericValue(c);
            String letter;
            switch (digit) {
                case 1:
                    letter = "a";
                    break;
                case 2:
                    letter = "b";
                    break;
                case 3:
                    letter = "c";
                    break;
                case 4:
                    letter = "d";
                    break;
                case 5:
                    letter = "e";
                    break;
                case 6:
                    letter = "f";
                    break;
                case 7:
                    letter = "g";
                    break;
                case 8:
                    letter = "h";
                    break;
                case 9:
                    letter = "i";
                    break;
                default:
                    letter = c + "";
                    break;
            }
            secretCode.append(letter);
        }
        return secretCode.toString();
    }
}
