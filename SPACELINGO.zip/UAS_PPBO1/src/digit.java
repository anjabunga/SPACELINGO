import javax.swing.*;

public class digit {
    public JPanel digitPanel;
    private JTextField textField1;
    private JButton GOButton;

    public digit(JFrame frame, DataContainer dataContainer) {

        GOButton.addActionListener(e -> {
            dataContainer.setDigity(String.valueOf(textField1.getText()));

            if (dataContainer.getDigity().isEmpty()) {
                JOptionPane.showMessageDialog(frame, "Input tidak boleh kosong!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            if (dataContainer.getDigity().length() > 3) {
                JOptionPane.showMessageDialog(null, "Angka Harus 3 Digit!", "Error", JOptionPane.ERROR_MESSAGE);

                textField1.setText("");

            } else {
                // Beralih ke frame result
                result resultPanel = new result(dataContainer);
                frame.setContentPane(resultPanel.resultPanel);
                frame.revalidate();
            }
        });
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Digit");
        DataContainer dataContainer = new DataContainer();
        digit digitPanel = new digit(frame, dataContainer);
        frame.setContentPane(digitPanel.digitPanel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}
