import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;



public class result {
    JPanel resultPanel;
    private JTextField textTranslate;
    private JTextField hitungVocal;
    private JTextField textKodeRahasia;
    private JTextField iniDigitTextField;
    private JTextField iniTeksTextField;
    private JButton HOMEButton;

    public result(DataContainer dataContainer) {
        // Menggunakan data dari DataContainer
        iniDigitTextField.setText(dataContainer.getDigity());
        iniTeksTextField.setText(dataContainer.getWordy());

        String alienSentence = translateToAlienLanguage(dataContainer.getWordy());
        textTranslate.setText(alienSentence);

        String secretCode = translateSecretCode(dataContainer.getDigity());
        textKodeRahasia.setText(secretCode);

        // Hitung jumlah huruf vokal pada textKodeRahasia
        int vowelCount = countVowelsInSentence(secretCode);
        hitungVocal.setText(String.valueOf(vowelCount));
        HOMEButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
    }

    private static String translateToAlienLanguage(String sentence) {
        StringBuilder alienSentence = new StringBuilder();
        Random random = new Random();

        for (char c : sentence.toCharArray()) {
            if ("aeiou".contains(Character.toLowerCase(c) + "")) {
                char randomChar = (char) ('A' + random.nextInt(26));
                alienSentence.append(randomChar);
            } else {
                alienSentence.append(c);
            }
        }
        return alienSentence.toString();
    }

    private static String translateSecretCode(String inputCode) {
        StringBuilder secretCode = new StringBuilder();
        for (char c : inputCode.toCharArray()) {
            Integer digit = Character.getNumericValue(c);
            String letter;
            switch (digit) {
                case 1:
                    letter = "a";
                    break;
                case 2:
                    letter = "b";
                    break;
                case 3:
                    letter = "c";
                    break;
                case 4:
                    letter = "d";
                    break;
                case 5:
                    letter = "e";
                    break;
                case 6:
                    letter = "f";
                    break;
                case 7:
                    letter = "g";
                    break;
                case 8:
                    letter = "h";
                    break;
                case 9:
                    letter = "i";
                    break;
                default:
                    letter = c + "";
                    break;
            }
            secretCode.append(letter);
        }
        return secretCode.toString();
    }

    private static int countVowelsInSentence(String sentence) {
        int count = 0;
        for (char c : sentence.toCharArray()) {
            if ("aeiou".contains(Character.toLowerCase(c) + "")) {
                count++;
            }
        }
        return count;
    }
}
