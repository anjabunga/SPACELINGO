import javax.swing.*;



public class words {
    protected JPanel GUIPanel;
    private JTextField textField1;
    private JButton GOButton;

    public words(JFrame frame, DataContainer dataContainer) {

        GOButton.addActionListener(e -> {
            dataContainer.setWordy(String.valueOf(textField1.getText()));

            // Periksa apakah textField1 tidak kosong
            if (dataContainer.getWordy().isEmpty()) {
                JOptionPane.showMessageDialog(frame, "Input tidak boleh kosong!", "Error", JOptionPane.ERROR_MESSAGE);
                return; // Kembalikan kontrol jika input kosong
            }

            // Beralih ke frame digit
            digit digitPanel = new digit(frame, dataContainer);
            frame.setContentPane(digitPanel.digitPanel);
            frame.revalidate();
        });
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Words");
        DataContainer dataContainer = new DataContainer();
        words wordsPanel = new words(frame, dataContainer);
        frame.setContentPane(wordsPanel.GUIPanel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}
